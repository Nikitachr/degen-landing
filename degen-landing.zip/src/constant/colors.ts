export const bgColors = [
  {
    value: 'white',
    hex: "#FFFFFF"
  },
  {
    value: 'black',
    hex: "#000000"
  },
  {
    value: 'yellow',
    hex: "#F7E26B"
  },
  {
    value: 'red',
    hex: "#BE2633"
  },
  {
    value: 'daekbrown',
    hex: "#493C2B"
  },
  {
    value: 'green',
    hex: "#44891A"
  },
  {
    value: 'seablue',
    hex: "#005784"
  },
  {
    value: 'cloudblue',
    hex: "#B2DCEF"
  }
]
